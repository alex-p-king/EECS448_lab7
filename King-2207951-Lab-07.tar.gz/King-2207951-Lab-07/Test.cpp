#include <iostream>
#include "LinkedListOfInts.h"
#include "Test.h"


Test::Test()
{
}
Test::~Test()
{
}
void Test::runTests()
{

  std::cout << "##############################################################\nTEST EMPTY\n";
  testEmpty();
  std::cout << "##############################################################\nTEST SIZE\n";
  testSize();
  std::cout << "##############################################################\nTEST SEARCH\n";
  testSearch();
  std::cout << "##############################################################\nTEST ADDBACK\n";
  testAddBack();
  std::cout << "##############################################################\nTEST ADDFRONT\n";
  testAddFront();
  std::cout << "##############################################################\nTEST REMOVEBACK\n";
  testRemoveBack();
  std::cout << "##############################################################\nTEST REMOVEFRONT\n";
  testRemoveFront();
  std::cout << "##############################################################\nEND OF TESTS\n";
}
void Test::testEmpty()
{
  std::cout << "Creating list...\n";
  LinkedListOfInts myList;
  std::cout << "checking if initialized list is empty: ";
  if(myList.isEmpty() == true)
  {
    std::cout << "list is empty -> TEST PASSED\n";
  }
  else
  {
    std::cout << "List initialized to a non-empty value -> TEST FAILED\n";
  }
  //add valus to the list and check to see if its empty
  std::cout << "adding value to list\n";
  myList.addFront(1);
  std::cout << "checking if list is empty: ";
  if(myList.isEmpty() == true){
    std::cout << "non-empty list returned empty -> TEST FAILED\n";
  }
  else{
    std::cout << "non-empty list returned not empty -> TEST PASSED\n";
  }
}
void Test::testSize()
{
  LinkedListOfInts myList;
  std::cout << "empty list initialized\nchecking size...\n";
  if(myList.size() > 0){
    std::cout << "\nempty list returns size greater than 0 -> TEST FAILED\n";
  }
  else if(myList.size() < 0){
    std::cout << "\nempty list returns size less than 0 -> TEST FAILED\n";
  }
  else{
    std::cout << "empty list returns size of 0 -> TEST PASSED\n";
  }
  std::cout << "adding values to list...\n";
  myList.addBack(1);
  myList.addBack(2);
  myList.addBack(3);
  myList.addFront(4);
  myList.addFront(5);
  myList.addFront(6);
  std::cout << "3 values added using addBack() and 3 values added using addFront(), expected value of size = 6\n";
  if(myList.size() < 6){
    std::cout << "size returned is less than 6...\n";
    std::cout << "testing addFront...\n";

    //#TODO: initialize a new list and test if addFront() then size() returns a correct value.

  }
  else if(myList.size() > 6){
    std::cout << "size returned is greater than expected...\n";
    std::cout << "testing addFront then checking if size is greater than expected\n";
    //#TODO: initialize a new list and check if addFront() then size() returns results greater than expected.
    std::cout << "testing addBack then checking if size is greater than expected\n";
    //#TODO: initiailize new list then check if addBack() followed by size() returns values greater than expected.

  }
  else{
    std::cout << "Test passed, addFront and addBack followed by size() return correct size of list.";
  }
}
void Test::testSearch()
{
  LinkedListOfInts myList;
  std::cout << "Checking if search returns true for on empty list\n";
  std::cout << "Searching for 0 -> ";
  if(myList.search(0) == true ){
    std::cout << "TEST FAILED\n";
  }
  else{
    std::cout << "TEST PASSED\n";
  }
  std::cout << "Searching for -1 -> ";
  if(myList.search(-1) == true)
  {
    std::cout << "TEST FAILED\n";
  }
  else{
    std::cout << "TEST PASSED\n";
  }
  std::cout << "Searching for 1 -> ";
  if(myList.search(1) == true)
  {
    std::cout << "TEST FAILED\n";
  }
  else{
    std::cout << "TEST PASSED\n";
  }
  //Add values to list then run all checks again
  std::cout << "Adding values to list\n";
  for(int i = 10; i < 0; i--){
    std::cout << "adding " << i << " to front" << std::endl;
    myList.addFront(i);
  }
  for(int i = 11; i < 20; i++){
    std::cout << "adding " << i << " to back" << std::endl;
    myList.addBack(i);
  }
  std::cout << "Running search for values added to list\n";
  std::cout << "Searching for 0 -> ";
  if(myList.search(0) == true ){
    std::cout << "TEST PASSED\n";
  }
  else{
    std::cout << "TEST FAILED\n";
  }
  std::cout << "Searching for -1 -> ";
  if(myList.search(-1) == true)
  {
    std::cout << "TEST FAILED\n";
  }
  else{
    std::cout << "TEST PASSED\n";
  }
  std::cout << "Searching for 1 -> ";
  if(myList.search(1) == true)
  {
    std::cout << "TEST PASSED\n";
  }
  else{
    std::cout << "TEST FAILED\n";
  }

  //test addback values
  std::cout << "Searching for 11 -> ";
  if(myList.search(11) == true ){
    std::cout << "TEST PASSED\n";
  }
  else{
    std::cout << "TEST FAILED\n";
  }
  std::cout << "Searching for 15 -> ";
  if(myList.search(15) == true)
  {
    std::cout << "TEST PASSED\n";
  }
  else{
    std::cout << "TEST FAILED\n";
  }
  std::cout << "Searching for 19 -> ";
  if(myList.search(19) == true)
  {
    std::cout << "TEST PASSED\n";
  }
  else{
    std::cout << "TEST FAILED\n";
  }
}
void Test::testAddBack()
{
  LinkedListOfInts myList;
  for (int i = 0; i < 25; i++)
  {
    myList.addBack(i);
  }
  std::vector<int> listVector = myList.toVector();
  std::vector<int> testVector;
  for(int i = 0; i < 25; i++){
    testVector.push_back(i);
  }
  std::cout << "checking if addBack and toVector produces same result as pushing to vector function from std library -> ";
  if(testVector == listVector){
    std::cout << "TEST PASSED\n";
  }
  else{
    std::cout << "TEST FAILED\n";
  }
}
void Test::testAddFront()
{
  LinkedListOfInts myList;
  std::vector<int> myVectorList;
  //Add values to the list using addfront()
  for(int i = 0; i < 3 ; i++){
    std::cout << "Adding " << i << " to list.\n";
    myList.addFront(i);
  }
  for(int i = 2; i > -1; i--){
    std::cout << "Adding " << i << " to vector\n";
    myVectorList.push_back(i);
  }
  if(myList.toVector() == myVectorList){
    std::cout << "Testing addFront() -> TEST PASSED\n";
  }
  else{
    std::cout << "Testing addFront() -> TEST FAILED\n";
  }

}
void Test::testRemoveBack()
{
  //create list
  LinkedListOfInts myList;
  //add values to list
  for(int i = 0; i < 10; i++){
    std::cout << "adding " << i << " to list\n";
    myList.addBack(i);
  }
  //call remove front and compare if value is removed from list
  int expected = 10;
  for(int i = 0; i < 10; i++){
    std::cout << "calling removeBack()\n";
    myList.removeBack();
    expected--;
    std::cout << "testing size: expected = " << expected << ", actual = " << myList.toVector().size();
    if(myList.toVector().size() != expected){
      std::cout << " -> TEST FAILED\n";
    }
    else{
      std::cout << " -> TEST PASSED\n";
    }
  }
}

void Test::testRemoveFront()
{
  //create list
  LinkedListOfInts myList;
  //add values to list
  for(int i = 0; i < 10; i++){
    std::cout << "adding " << i << " to list\n";
    myList.addBack(i);
  }
  //call remove front and compare if value is removed from list
  int expected = 10;
  for(int i = 0; i < 10; i++){
    std::cout << "calling removeFront()\n";
    myList.removeFront();
    expected--;
    std::cout << "testing size: expected = " << expected << ", actual = " << myList.toVector().size();
    if(myList.toVector().size() != expected){
      std::cout << " -> TEST FAILED\n";
    }
    else{
      std::cout << " -> TEST PASSED\n";
    }
  }
}
