/**
*	@file List.h
*	@author
*	@date
*	@brief A List ADT
*/

#ifndef TEST_H
#define TEST_H

class Test
{
	public:
		Test();
		~Test();
		/** @pre None.
		*   @post calls all other tests and adds formatting to terminal
		*/
		void runTests();
		/** @pre None.
		*   @post checks if an initialized list is empty and if a list with one element added is empty then prints results to screen.
		*/
		void testEmpty();
		/** @pre None.
		*   @post linkedlist is created and tests to see if the number of elements in the list is the same as the number of elements added.
		*/
		void testSize();
		/** @pre None.
		*   @post adds value to a list then searches to see if the value is in the list
		*/
		void testSearch();
		/** @pre None.
		*   @post uses add back to add values to a list, converts the list to a vector using toVector() then searches the vector to see if the values are in the vector.
		*/
		void testAddBack();
		/** @pre None.
		*   @post uses addFront() to add values to a list, converts the list to a vector using toVector() then searches the vector to see if the values are in the vector.
		*/
		void testAddFront();
		/** @pre None.
		*   @post Populates a list then tests to see if values are removed.
		*/
		void testRemoveBack();
		/** @pre None.
		*   @post Populates a list then tests to see if values are removed.
		*/
		void testRemoveFront();
	private:
};

#endif
